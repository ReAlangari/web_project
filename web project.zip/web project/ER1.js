const date = new Date();
current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate();
document.getElementById("DATE").innerHTML = current_date;

